"""Control-room API: hazards as GeoJSON, provenance, vehicles, health, and a live event socket."""

from __future__ import annotations

import asyncio
import json
import logging
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles

from ..agents.sentinel import Sentinel
from ..config import get_settings
from ..connectors.boundaries import Boundaries
from ..db import close_pool, get_pool, init_schema
from ..events import STREAM, get_redis, send_command
from ..provenance import Fetcher, raw_body
from ..traccar_link import TraccarLink

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("rasad.api")

WEB_DIR = Path(__file__).resolve().parents[2] / "web"
SOURCES = ["sachet", "imd_cap", "gdacs", "river_watch"]


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    await init_schema()
    pool = await get_pool()
    app.state.pool = pool
    app.state.sentinel = None
    app.state.traccar = TraccarLink(pool)
    fetcher = Fetcher(pool)
    if s.embed_worker:
        app.state.sentinel = Sentinel(pool, fetcher, Boundaries(s.boundaries_path))
        await app.state.sentinel.start()
        await app.state.traccar.start()
    yield
    if app.state.sentinel:
        await app.state.sentinel.stop()
    await app.state.traccar.stop()
    await fetcher.aclose()
    await close_pool()


app = FastAPI(title="RASAD control room", lifespan=lifespan)


def _iso(v):
    return v.isoformat() if isinstance(v, datetime) else v


@app.get("/health")
async def health():
    s = get_settings()
    pool = app.state.pool
    now = datetime.now(UTC)
    rows = {r["source"]: r for r in await pool.fetch("SELECT * FROM source_status")}
    feeds = []
    for src in SOURCES:
        r = rows.get(src)
        if r is None:
            feeds.append({"source": src, "state": "waiting", "last_success": None})
            continue
        age = (now - r["last_success"]).total_seconds() if r["last_success"] else None
        if age is None:
            state = "down"
        elif age > s.stale_after * (8 if src == "river_watch" else 1):
            state = "stale"
        elif r["consecutive_failures"]:
            state = "degraded"
        else:
            state = "ok"
        feeds.append(
            {
                "source": src,
                "state": state,
                "last_success": _iso(r["last_success"]),
                "last_attempt": _iso(r["last_attempt"]),
                "age_seconds": int(age) if age is not None else None,
                "consecutive_failures": r["consecutive_failures"],
                "last_error": r["last_error"],
                "items_last_run": r["items_last_run"],
                "last_raw_fetch_id": r["last_raw_fetch_id"],
            }
        )
    try:
        redis_ok = bool(await get_redis().ping())
    except Exception:
        redis_ok = False
    return {
        "now": now.isoformat(),
        "database": True,
        "redis": redis_ok,
        "worker_embedded": app.state.sentinel is not None,
        "feeds": feeds,
        "traccar": app.state.traccar.health(),
    }


@app.get("/api/hazards")
async def hazards(include_inactive: bool = False):
    pool = app.state.pool
    rows = await pool.fetch(
        """SELECT h.id, h.kind, h.title, h.severity, h.certainty, h.urgency, h.onset, h.expires, h.located_by,
                  h.area_desc, h.status, h.first_seen, h.last_updated, h.attrs,
                  ST_AsGeoJSON(h.geom, 5)::json AS geometry,
                  ST_AsGeoJSON(ST_PointOnSurface(h.geom), 5)::json AS label_point,
                  COALESCE(json_agg(json_build_object(
                      'source', s.source, 'ref', s.source_ref, 'url', s.source_url, 'sender', s.sender,
                      'sent', s.sent, 'msg_type', s.msg_type, 'raw_fetch_id', s.raw_fetch_id)
                    ORDER BY s.sent DESC NULLS LAST) FILTER (WHERE s.source IS NOT NULL), '[]') AS sources
           FROM hazard h LEFT JOIN hazard_source s ON s.hazard_id = h.id
           WHERE ($1 OR h.status='active')
           GROUP BY h.id
           ORDER BY h.severity DESC, h.last_updated DESC
           LIMIT 500""",
        include_inactive,
    )
    features = []
    for r in rows:
        attrs = r["attrs"] or {}
        features.append(
            {
                "type": "Feature",
                "id": str(r["id"]),
                "geometry": r["geometry"],
                "properties": {
                    "id": str(r["id"]),
                    "kind": r["kind"],
                    "title": r["title"],
                    "severity": r["severity"],
                    "certainty": r["certainty"],
                    "urgency": r["urgency"],
                    "onset": _iso(r["onset"]),
                    "expires": _iso(r["expires"]),
                    "located_by": r["located_by"],
                    "area_desc": r["area_desc"],
                    "status": r["status"],
                    "first_seen": _iso(r["first_seen"]),
                    "last_updated": _iso(r["last_updated"]),
                    "label_point": r["label_point"],
                    "river_watch": attrs.get("river_watch"),
                    "matched_areas": [m.get("matched_areas") for m in (attrs.get("messages") or {}).values() if m.get("matched_areas")],
                    "sources": r["sources"],
                },
            }
        )
    return {"type": "FeatureCollection", "features": features, "generated_at": datetime.now(UTC).isoformat()}


@app.get("/api/hazards/{hazard_id}")
async def hazard_detail(hazard_id: str):
    pool = app.state.pool
    h = await pool.fetchrow("SELECT id, attrs FROM hazard WHERE id::text=$1", hazard_id)
    if h is None:
        raise HTTPException(404, "hazard not found")
    points = await pool.fetch(
        """SELECT p.id, p.name, p.road_class, p.osm_ref, ST_Y(p.geom) AS lat, ST_X(p.geom) AS lon,
                  p.threshold_m3s, p.warning_m3s, p.threshold_method, p.threshold_raw_fetch_id, p.no_river, p.forecast_at,
                  COALESCE(json_agg(json_build_object('day', f.day, 'discharge', f.discharge, 'median', f.q_median,
                      'p25', f.q_p25, 'p75', f.q_p75, 'min', f.q_min, 'max', f.q_max, 'exceed_prob', f.exceed_prob,
                      'raw_fetch_id', f.raw_fetch_id) ORDER BY f.day) FILTER (WHERE f.day IS NOT NULL), '[]') AS forecast
           FROM river_point_hazard rh JOIN river_point p ON p.id = rh.river_point_id
           LEFT JOIN river_forecast f ON f.river_point_id = p.id AND f.day >= current_date
           WHERE rh.hazard_id = $1
           GROUP BY p.id ORDER BY p.road_class NULLS LAST""",
        h["id"],
    )
    return {
        "id": str(h["id"]),
        "messages": (h["attrs"] or {}).get("messages", {}),
        "river_points": [
            {**{k: _iso(v) for k, v in dict(p).items() if k != "forecast"}, "forecast": p["forecast"]} for p in points
        ],
    }


@app.get("/api/river-points")
async def river_points():
    rows = await app.state.pool.fetch(
        """SELECT p.id, p.name, p.road_class, ST_Y(p.geom) AS lat, ST_X(p.geom) AS lon, p.threshold_m3s, p.no_river,
                  (SELECT max(exceed_prob) FROM river_forecast f WHERE f.river_point_id=p.id
                     AND f.day BETWEEN current_date AND current_date + 3) AS p3
           FROM river_point p
           WHERE EXISTS (SELECT 1 FROM river_point_hazard rh JOIN hazard h ON h.id=rh.hazard_id
                         WHERE rh.river_point_id=p.id AND h.status='active')"""
    )
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [r["lon"], r["lat"]]},
                "properties": {"id": r["id"], "name": r["name"], "road_class": r["road_class"],
                               "threshold_m3s": r["threshold_m3s"], "no_river": r["no_river"], "p3": r["p3"]},
            }
            for r in rows
        ],
    }


@app.get("/api/vehicles")
async def vehicles():
    rows = await app.state.pool.fetch(
        """SELECT DISTINCT ON (p.device_id) p.device_id, v.name, p.fix_time, p.speed_kmh, p.course,
                  ST_Y(p.geom) AS lat, ST_X(p.geom) AS lon
           FROM vehicle_position p LEFT JOIN vehicle v ON v.device_id = p.device_id
           ORDER BY p.device_id, p.fix_time DESC"""
    )
    now = datetime.now(UTC)
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [r["lon"], r["lat"]]},
                "properties": {
                    "device_id": r["device_id"],
                    "name": r["name"] or f"Device {r['device_id']}",
                    "fix_time": _iso(r["fix_time"]),
                    "age_seconds": int((now - r["fix_time"]).total_seconds()),
                    "speed_kmh": r["speed_kmh"],
                    "course": r["course"],
                },
            }
            for r in rows
        ],
    }


@app.get("/api/raw/{raw_id}")
async def raw(raw_id: int, meta: bool = False):
    got = await raw_body(app.state.pool, raw_id)
    if got is None:
        raise HTTPException(404, "no such fetch")
    body, ctype, info = got
    if meta:
        return info
    return Response(
        content=body,
        media_type=(ctype or "application/octet-stream").split(";")[0] if body else "text/plain",
        headers={"X-Rasad-Source": info["source"], "X-Rasad-Url": info["url"], "X-Rasad-Fetched-At": info["fetched_at"]},
    )


@app.get("/api/events")
async def events(since_id: int = 0, limit: int = 100):
    rows = await app.state.pool.fetch(
        "SELECT id, at, type, payload FROM event_log WHERE id > $1 ORDER BY id DESC LIMIT $2", since_id, min(limit, 500)
    )
    return [{"id": r["id"], "at": _iso(r["at"]), "type": r["type"], "payload": r["payload"]} for r in rows]


@app.post("/api/refresh/{source}")
async def refresh(source: str):
    if source not in SOURCES:
        raise HTTPException(400, f"unknown source; use one of {SOURCES}")
    if app.state.sentinel is not None:
        return {"triggered": app.state.sentinel.trigger(source), "via": "in-process"}
    return {"triggered": await send_command({"cmd": "refresh", "source": source}), "via": "redis"}


@app.websocket("/ws")
async def ws(socket: WebSocket):
    """Pushes every event to the browser. Uses Redis Streams; if Redis is down,
    tails event_log in Postgres instead."""
    await socket.accept()
    pool = app.state.pool
    last_db_id = await pool.fetchval("SELECT COALESCE(max(id), 0) FROM event_log")
    last_stream = "$"
    try:
        while True:
            sent_any = False
            try:
                resp = await get_redis().xread({STREAM: last_stream}, block=5000, count=50)
                for _s, entries in resp or []:
                    for entry_id, f in entries:
                        last_stream = entry_id
                        last_db_id = max(last_db_id, int(f.get("id", 0)))
                        await socket.send_text(json.dumps({"id": int(f.get("id", 0)), "type": f["type"], "payload": json.loads(f["payload"])}))
                        sent_any = True
            except Exception:
                rows = await pool.fetch(
                    "SELECT id, type, payload FROM event_log WHERE id > $1 ORDER BY id LIMIT 50", last_db_id
                )
                for r in rows:
                    last_db_id = r["id"]
                    await socket.send_text(json.dumps({"id": r["id"], "type": r["type"], "payload": r["payload"]}, default=str))
                    sent_any = True
                if not sent_any:
                    await asyncio.sleep(3)
            if not sent_any:
                await socket.send_text(json.dumps({"type": "heartbeat"}))
    except WebSocketDisconnect:
        return


@app.get("/")
async def index():
    return FileResponse(WEB_DIR / "index.html")


app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")


@app.exception_handler(Exception)
async def unhandled(_req, exc: Exception):
    log.exception("unhandled error")
    return JSONResponse({"error": type(exc).__name__, "detail": str(exc)}, status_code=500)
