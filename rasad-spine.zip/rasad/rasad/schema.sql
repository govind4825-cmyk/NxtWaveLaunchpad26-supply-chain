-- RASAD incident state. Idempotent: safe to run on every start.
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Every external fetch is stored as-is. This is the provenance trail judges can inspect.
CREATE TABLE IF NOT EXISTS raw_fetch (
    id            BIGSERIAL PRIMARY KEY,
    source        TEXT        NOT NULL,
    url           TEXT        NOT NULL,
    fetched_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    http_status   INTEGER,
    ok            BOOLEAN     NOT NULL,
    content_type  TEXT,
    body          BYTEA,
    sha256        TEXT,
    error         TEXT,
    elapsed_ms    INTEGER
);
CREATE INDEX IF NOT EXISTS raw_fetch_source_idx ON raw_fetch (source, fetched_at DESC);
CREATE INDEX IF NOT EXISTS raw_fetch_sha_idx ON raw_fetch (source, sha256);

CREATE TABLE IF NOT EXISTS source_status (
    source               TEXT PRIMARY KEY,
    last_attempt         TIMESTAMPTZ,
    last_success         TIMESTAMPTZ,
    last_error           TEXT,
    consecutive_failures INTEGER NOT NULL DEFAULT 0,
    last_raw_fetch_id    BIGINT REFERENCES raw_fetch (id),
    items_last_run       INTEGER
);

CREATE TABLE IF NOT EXISTS hazard (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    kind          TEXT        NOT NULL,
    title         TEXT        NOT NULL,
    severity      SMALLINT    NOT NULL,          -- 0 unknown .. 4 extreme (CAP severity)
    certainty     REAL        NOT NULL,          -- 0..1 from CAP certainty
    urgency       TEXT,
    onset         TIMESTAMPTZ,
    expires       TIMESTAMPTZ,
    geom          geometry(MultiPolygon, 4326),  -- NULL when the alert could not be located
    area_desc     TEXT,
    located_by    TEXT        NOT NULL,          -- polygon | circle | district | gdacs | none
    status        TEXT        NOT NULL DEFAULT 'active',  -- active | expired | cancelled
    first_seen    TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_updated  TIMESTAMPTZ NOT NULL DEFAULT now(),
    attrs         JSONB       NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS hazard_geom_idx ON hazard USING GIST (geom);
CREATE INDEX IF NOT EXISTS hazard_status_idx ON hazard (status, kind);

-- One hazard can be backed by several agency messages (SACHET, IMD CAP, GDACS).
CREATE TABLE IF NOT EXISTS hazard_source (
    hazard_id     UUID        NOT NULL REFERENCES hazard (id) ON DELETE CASCADE,
    source        TEXT        NOT NULL,
    source_ref    TEXT        NOT NULL,          -- CAP identifier or GDACS type:event:episode
    source_url    TEXT,
    sender        TEXT,
    sent          TIMESTAMPTZ,
    msg_type      TEXT,
    raw_fetch_id  BIGINT REFERENCES raw_fetch (id),
    added_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (source, source_ref)
);
CREATE INDEX IF NOT EXISTS hazard_source_hazard_idx ON hazard_source (hazard_id);

-- River crossings watched with GloFAS forecasts.
CREATE TABLE IF NOT EXISTS river_point (
    id                     BIGSERIAL PRIMARY KEY,
    osm_ref                TEXT UNIQUE NOT NULL,
    name                   TEXT,
    road_class             TEXT,
    geom                   geometry(Point, 4326) NOT NULL,
    model_lat              DOUBLE PRECISION,
    model_lon              DOUBLE PRECISION,
    threshold_m3s          DOUBLE PRECISION,
    warning_m3s            DOUBLE PRECISION,
    threshold_method       TEXT,
    threshold_raw_fetch_id BIGINT REFERENCES raw_fetch (id),
    no_river               BOOLEAN NOT NULL DEFAULT false,
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    forecast_at            TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS river_point_geom_idx ON river_point USING GIST (geom);

CREATE TABLE IF NOT EXISTS river_point_hazard (
    river_point_id BIGINT NOT NULL REFERENCES river_point (id) ON DELETE CASCADE,
    hazard_id      UUID   NOT NULL REFERENCES hazard (id) ON DELETE CASCADE,
    PRIMARY KEY (river_point_id, hazard_id)
);

CREATE TABLE IF NOT EXISTS river_forecast (
    river_point_id BIGINT NOT NULL REFERENCES river_point (id) ON DELETE CASCADE,
    day            DATE   NOT NULL,
    discharge      DOUBLE PRECISION,
    q_min          DOUBLE PRECISION,
    q_p25          DOUBLE PRECISION,
    q_median       DOUBLE PRECISION,
    q_p75          DOUBLE PRECISION,
    q_max          DOUBLE PRECISION,
    exceed_prob    REAL,
    raw_fetch_id   BIGINT REFERENCES raw_fetch (id),
    fetched_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (river_point_id, day)
);

-- Live phone GPS from Traccar.
CREATE TABLE IF NOT EXISTS vehicle (
    device_id    INTEGER PRIMARY KEY,
    name         TEXT,
    unique_id    TEXT,
    status       TEXT,
    last_update  TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS vehicle_position (
    id           BIGSERIAL PRIMARY KEY,
    traccar_id   BIGINT UNIQUE,
    device_id    INTEGER     NOT NULL,
    fix_time     TIMESTAMPTZ NOT NULL,
    server_time  TIMESTAMPTZ,
    geom         geometry(Point, 4326) NOT NULL,
    speed_kmh    REAL,
    course       REAL,
    attrs        JSONB NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS vehicle_position_device_idx ON vehicle_position (device_id, fix_time DESC);

-- Append-only event log. Redis carries events live; this table is the durable copy and audit trail.
CREATE TABLE IF NOT EXISTS event_log (
    id       BIGSERIAL PRIMARY KEY,
    at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    type     TEXT        NOT NULL,
    payload  JSONB       NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS event_log_at_idx ON event_log (at DESC);
