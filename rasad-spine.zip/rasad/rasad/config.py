"""Runtime settings, read from environment variables or a .env file."""

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="RASAD_", extra="ignore")

    database_url: str = "postgresql://rasad:rasad@localhost:5432/rasad"
    redis_url: str = "redis://localhost:6379/0"

    # Hazard feeds. SACHET publishes a national feed plus state feeds; add state
    # feed URLs to SACHET_EXTRA_FEEDS (comma separated) to widen coverage.
    sachet_feed: str = "https://sachet.ndma.gov.in/cap_public_website/rss/rss_india.xml"
    sachet_extra_feeds: str = ""
    imd_cap_feed: str = "https://cap-sources.s3.amazonaws.com/in-imd-en/rss.xml"
    gdacs_base: str = "https://www.gdacs.org/gdacsapi/api"
    openmeteo_flood_base: str = "https://flood-api.open-meteo.com/v1/flood"
    overpass_url: str = "https://overpass-api.de/api/interpreter"
    worldpop_base: str = "https://api.worldpop.org/v1"

    # Poll cadence in seconds (section 3 of the design doc).
    sachet_every: int = 300
    imd_cap_every: int = 300
    gdacs_every: int = 900
    river_watch_every: int = 3600

    # A source older than this many seconds is shown as stale.
    stale_after: int = 1800

    # India bounding box (west, south, east, north) used to keep GDACS events relevant.
    region_bbox: str = "66.0,6.0,98.5,37.5"

    # District boundaries for CAP alerts that carry no polygon.
    boundaries_path: str = "data/india_district.geojson"

    # Traccar server for live phone GPS.
    traccar_url: str = "http://localhost:8082"
    traccar_email: str = ""
    traccar_password: str = ""

    # Run the Sentinel and Traccar link inside the API process (simplest deploy).
    embed_worker: bool = True

    http_timeout: float = 25.0
    user_agent: str = "RASAD-hackathon/0.1 (relief logistics research)"

    @property
    def bbox(self) -> tuple[float, float, float, float]:
        w, s, e, n = (float(x) for x in self.region_bbox.split(","))
        return w, s, e, n

    @property
    def sachet_feeds(self) -> list[str]:
        extra = [u.strip() for u in self.sachet_extra_feeds.split(",") if u.strip()]
        return [self.sachet_feed, *extra]


@lru_cache
def get_settings() -> Settings:
    return Settings()
