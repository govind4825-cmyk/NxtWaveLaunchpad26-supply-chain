# RASAD: anticipatory relief logistics swarm

RASAD (रसद, "provisions") reads India's official hazard feeds, works out which communities are about to be cut off, and moves relief to them before the last safe road closes. This repository is the build for Theme 2, Problem 4: Autonomous Emergency Response & Supply Chain Logistics Swarm.

**Status: spine running.** The Sentinel agent, provenance store, river watch, live phone tracking and the control-room map work end to end. Cartographer (access windows), Quartermaster (needs), Procurer (Beckn orders), Dispatcher (routing) and Warden (guardrails) are next; see [Roadmap](#roadmap).

## What runs today

- **Sentinel** polls NDMA SACHET and IMD CAP feeds every 5 minutes and GDACS every 15 minutes, parses CAP 1.1/1.2 and GDACS footprints, and turns them into hazards in PostGIS.
- **Fusion** merges the same event reported by several agencies (same kind, overlapping time, footprint IoU ≥ 0.4 or containment ≥ 80%), applies CAP `Update` and `Cancel` messages through their `references`, and keeps the most precise footprint.
- **District fallback** places CAP alerts that only name districts, using GADM district boundaries with alias and fuzzy matching. These are drawn dashed and flagged "placed by district name".
- **River watch** finds road bridges over rivers inside moderate-or-worse flood, rain and cyclone hazards (OpenStreetMap Overpass), derives each river cell's own flood level from GloFAS reanalysis (median annual maximum, 1984–2022), and tracks the share of the GloFAS ensemble forecast above it for the next 16 days.
- **Provenance**: every HTTP call is stored in `raw_fetch` with URL, time, status and payload. Every hazard, source and forecast row points at the fetch it came from, and the UI links to `/api/raw/{id}`.
- **Live GPS** from drivers' phones through a Traccar server and its WebSocket, with REST polling as fallback.
- **Control room** (MapLibre): hazards by severity, river crossings by flood probability, vehicles, feed health with last-success times, a provenance drawer and a live event ticker over WebSocket.

## Architecture

```mermaid
flowchart LR
  subgraph Live inputs
    S[SACHET CAP feed]
    I[IMD CAP feed]
    G[GDACS events + polygons]
    O[OSM Overpass bridges]
    F[GloFAS via Open-Meteo]
    T[Traccar phone GPS]
  end
  subgraph RASAD
    P[(raw_fetch provenance)]
    SE[Sentinel]
    FU[Fusion + district fallback]
    RW[River watch]
    DB[(PostGIS incident state)]
    EV[[Redis Streams + event_log]]
    API[FastAPI + WebSocket]
  end
  S & I & G --> P --> SE --> FU --> DB
  O & F --> P --> RW --> DB
  T --> API
  DB --> EV --> API --> UI[Control room map]
```

Planned agents on the same state: Cartographer, Quartermaster, Procurer, Dispatcher, Warden. The full design is in the project's solution doc.

## Run it

### With Docker (recommended)

```bash
cp .env.example .env
docker compose -f infra/docker-compose.yml up --build
```

Open http://localhost:8000 for the control room and http://localhost:8082 for Traccar.

### Without Docker

Needs Python 3.12+, PostgreSQL 16 with PostGIS, and Redis.

```bash
pip install -r requirements-dev.txt
python scripts/fetch_boundaries.py          # district boundaries, one time
createdb rasad                               # PostGIS extension is created on start
cp .env.example .env                         # edit the database URL if needed
uvicorn rasad.api.main:app --reload
```

The schema is applied automatically on start. To run the agents in a separate process, set `RASAD_EMBED_WORKER=false` and run `python -m rasad.worker`.

### Live phone tracking

1. Open Traccar at http://localhost:8082 and create the admin account. Put the same email and password in `.env` as `RASAD_TRACCAR_EMAIL` and `RASAD_TRACCAR_PASSWORD`, then restart the API.
2. On each driver's phone install **Traccar Client** (Android or iOS). Set the server URL to `http://<your-server-ip>:5055` and note the device identifier it shows.
3. In Traccar, add a device with that identifier. Positions appear on the RASAD map within seconds.

## API

| Endpoint | Returns |
| --- | --- |
| `GET /health` | Each feed's state (ok, degraded, stale, down), last success, last error, item count; Redis and Traccar status |
| `GET /api/hazards` | Active hazards as GeoJSON, each with every agency message behind it |
| `GET /api/hazards/{id}` | Message texts and watched river crossings with 16-day forecasts |
| `GET /api/river-points` | Watched crossings with 3-day flood probability |
| `GET /api/vehicles` | Latest position per device |
| `GET /api/raw/{id}` | The exact payload of a stored fetch (`?meta=true` for URL, time, status, hash) |
| `GET /api/events` | Recent events from the audit log |
| `POST /api/refresh/{source}` | Poll a source now (`sachet`, `imd_cap`, `gdacs`, `river_watch`) |
| `WS /ws` | Live events; falls back to tailing Postgres if Redis is down |

## Data sources and the no-dummy-data rule

| Source | Used for | Access |
| --- | --- | --- |
| [NDMA SACHET CAP feed](https://sachet.ndma.gov.in/cap_public_website/rss/rss_india.xml) | Official alerts from IMD, CWC, INCOIS, FSI and states | Open RSS |
| [IMD CAP feed](https://cap-sources.s3.amazonaws.com/in-imd-en/rss.xml) | IMD warnings, backup to SACHET | Open RSS |
| [GDACS API](https://www.gdacs.org/gdacsapi/api) | Cyclone and flood footprints | Open |
| [Open-Meteo Flood API](https://open-meteo.com/en/docs/flood-api) (GloFAS v4) | River discharge forecast and reanalysis | Open |
| [Overpass API](https://overpass-api.de) (OpenStreetMap) | Road bridges over rivers | Open |
| [geohacker/india](https://github.com/geohacker/india) district boundaries (GADM) | Placing alerts that only name districts | Open, downloaded by script |
| [Traccar](https://www.traccar.org) | Live phone GPS | Self-hosted |

Nothing in `rasad/` or `web/` contains hazard, stock, population or position data. Test files contain small format samples written to the CAP and RSS specs, used only to test the parsers. The app never loads them.

## How it handles failure

- A feed that errors is retried with backoff (up to 4x its interval) and shown as down or stale on the health strip; the other feeds keep running. SACHET and IMD CAP back each other up.
- Malformed CAP files are logged with the URL and skipped; the rest of the feed is still processed.
- Alerts without a polygon are placed by district name if possible, otherwise listed as "not on map", never dropped.
- GloFAS points off any modelled river are marked and skipped; missing ensemble values give no probability rather than a guess.
- Redis down: events still go to `event_log`, and the WebSocket tails Postgres.
- Traccar socket down: falls back to polling, reconnects with backoff.
- Repeated identical alerts are recognised by source and identifier and do not create duplicates.

## Tests

```bash
pytest                                                        # parsers and engine
RASAD_TEST_DATABASE_URL=postgresql://rasad:rasad@localhost:5432/rasad_test pytest tests/test_db.py   # PostGIS integration
```

## Roadmap

1. **Cartographer**: GraphHopper on a state OSM extract, road risk per time slice from hazards and river watch, access window per shelter.
2. **Quartermaster**: WorldPop exposure per shelter catchment × Sphere standards, public Needs Ledger.
3. **Procurer**: Beckn-ONIX BAP and a BPP for real local suppliers updating stock over WhatsApp.
4. **Dispatcher**: OR-Tools vehicle routing with access-window time windows, WhatsApp/SMS routes, re-planning on deviation or closure.
5. **Warden + LLM**: provenance and bounds checks before every commit, officer approval queue, message parsing in Indian languages.
