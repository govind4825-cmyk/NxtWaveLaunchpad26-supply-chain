/* RASAD control room. Every number shown here comes from /api, which comes from a stored raw fetch. */
(() => {
  const LOGISTICS = new Set(["cyclone", "flood", "heavy_rain", "landslide", "tsunami", "high_wave", "avalanche"]);
  const FEED_NAMES = { sachet: "SACHET (NDMA)", imd_cap: "IMD CAP", gdacs: "GDACS", river_watch: "River watch" };
  const SEV = ["Unknown", "Minor", "Moderate", "Severe", "Extreme"];
  const SEV_COLOR = ["#7b858c", "#7fb3a3", "#e9c46a", "#f08a4b", "#e0442b"];
  const state = { hazards: null, selected: null, onlyLogistics: true, lastEventId: 0 };

  const $ = (s) => document.querySelector(s);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const ago = (iso) => {
    if (!iso) return "never";
    const s = Math.max(0, (Date.now() - Date.parse(iso)) / 1000);
    if (s < 90) return `${Math.round(s)}s ago`;
    if (s < 5400) return `${Math.round(s / 60)}m ago`;
    if (s < 172800) return `${Math.round(s / 3600)}h ago`;
    return `${Math.round(s / 86400)}d ago`;
  };
  const when = (iso) => (iso ? new Date(iso).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }) : "—");
  const pct = (p) => (p == null ? "—" : `${Math.round(p * 100)}%`);
  const kindLabel = (k) => (k || "other").replace("_", " ");

  async function api(path, opts) {
    const r = await fetch(path, opts);
    if (!r.ok) throw new Error(`${path}: HTTP ${r.status}`);
    return r.json();
  }

  // ---------- clock ----------
  setInterval(() => {
    $("#clock").textContent = new Date().toLocaleTimeString("en-IN", { timeZone: "Asia/Kolkata", hour12: false }) + " IST";
  }, 1000);

  // ---------- map ----------
  const map = new maplibregl.Map({
    container: "map",
    center: [82.8, 22.6],
    zoom: 4.2,
    attributionControl: { compact: true },
    style: {
      version: 8,
      sources: {
        osm: {
          type: "raster",
          tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
          tileSize: 256,
          maxzoom: 19,
          attribution: "© OpenStreetMap contributors",
        },
      },
      layers: [
        { id: "bg", type: "background", paint: { "background-color": "#0f1418" } },
        { id: "osm", type: "raster", source: "osm", paint: { "raster-saturation": -0.85, "raster-brightness-max": 0.55, "raster-contrast": 0.1 } },
      ],
    },
  });
  map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");

  const empty = { type: "FeatureCollection", features: [] };
  map.on("load", () => {
    map.addSource("hazards", { type: "geojson", data: empty, promoteId: "id" });
    map.addSource("rivers", { type: "geojson", data: empty });
    map.addSource("vehicles", { type: "geojson", data: empty, promoteId: "device_id" });

    map.addLayer({
      id: "hz-fill", type: "fill", source: "hazards",
      paint: {
        "fill-color": ["match", ["get", "severity"], 4, SEV_COLOR[4], 3, SEV_COLOR[3], 2, SEV_COLOR[2], 1, SEV_COLOR[1], SEV_COLOR[0]],
        "fill-opacity": ["case", ["boolean", ["feature-state", "selected"], false], 0.5, ["+", 0.12, ["*", 0.25, ["get", "certainty"]]]],
      },
    });
    map.addLayer({
      id: "hz-line", type: "line", source: "hazards",
      paint: {
        "line-color": ["match", ["get", "severity"], 4, SEV_COLOR[4], 3, SEV_COLOR[3], 2, SEV_COLOR[2], 1, SEV_COLOR[1], SEV_COLOR[0]],
        "line-width": ["case", ["boolean", ["feature-state", "selected"], false], 2.5, 1],
        "line-dasharray": ["case", ["==", ["get", "located_by"], "district"], ["literal", [2, 2]], ["literal", [1, 0]]],
      },
    });
    map.addLayer({
      id: "rivers", type: "circle", source: "rivers",
      paint: {
        "circle-radius": ["interpolate", ["linear"], ["zoom"], 4, 3, 10, 7],
        "circle-color": ["case", ["==", ["get", "p3"], null], "#7b858c", [">=", ["get", "p3"], 0.5], "#e0442b", [">=", ["get", "p3"], 0.2], "#e9c46a", "#5cbf8a"],
        "circle-stroke-color": "#0f1418", "circle-stroke-width": 1.5,
      },
    });
    map.addLayer({
      id: "vehicles", type: "circle", source: "vehicles",
      paint: { "circle-radius": 7, "circle-color": "#6fb7ff", "circle-stroke-color": "#fff", "circle-stroke-width": 2,
        "circle-opacity": ["case", [">", ["get", "age_seconds"], 900], 0.4, 1] },
    });

    map.on("click", "hz-fill", (e) => select(e.features[0].properties.id, false));
    map.on("click", "rivers", (e) => {
      const p = e.features[0].properties;
      new maplibregl.Popup({ closeButton: false }).setLngLat(e.lngLat)
        .setHTML(`<b>${esc(p.name || "Unnamed bridge")}</b><br>${esc(p.road_class || "")} road<br>Flood probability, 3 days: <b>${pct(p.p3 === "null" ? null : Number(p.p3))}</b><br>Threshold ${p.threshold_m3s && p.threshold_m3s !== "null" ? Math.round(p.threshold_m3s) + " m³/s" : "pending"}`)
        .addTo(map);
    });
    map.on("click", "vehicles", (e) => {
      const p = e.features[0].properties;
      new maplibregl.Popup({ closeButton: false }).setLngLat(e.lngLat)
        .setHTML(`<b>${esc(p.name)}</b><br>Last fix ${ago(p.fix_time)}<br>${p.speed_kmh != null ? Math.round(p.speed_kmh) + " km/h" : ""}`)
        .addTo(map);
    });
    for (const l of ["hz-fill", "rivers", "vehicles"]) {
      map.on("mouseenter", l, () => (map.getCanvas().style.cursor = "pointer"));
      map.on("mouseleave", l, () => (map.getCanvas().style.cursor = ""));
    }
    refreshAll();
  });

  // ---------- feeds ----------
  async function loadHealth() {
    let h;
    try { h = await api("/health"); } catch (e) { $("#feeds").innerHTML = `<div class="empty">API unreachable: ${esc(e.message)}</div>`; return; }
    const cards = h.feeds.map((f) => `
      <div class="feed" title="${esc(f.last_error || "")}">
        <div class="row"><span class="st ${f.state}"></span><span class="nm">${esc(FEED_NAMES[f.source] || f.source)}</span></div>
        <div class="meta">${f.state === "waiting" ? "first run pending" : `${esc(f.state)} · ${ago(f.last_success)}`}${f.items_last_run != null ? ` · ${f.items_last_run} items` : ""}</div>
        ${f.last_raw_fetch_id ? `<div class="meta"><a href="/api/raw/${f.last_raw_fetch_id}" target="_blank" style="color:var(--accent)">raw payload #${f.last_raw_fetch_id}</a></div>` : ""}
        <button data-refresh="${f.source}" title="Poll now">↻</button>
      </div>`);
    const t = h.traccar;
    cards.push(`
      <div class="feed"><div class="row"><span class="st ${!t.enabled ? "" : t.connected ? "ok" : "down"}"></span><span class="nm">Phone GPS (Traccar)</span></div>
      <div class="meta">${!t.enabled ? "not configured" : t.connected ? `live · ${ago(t.last_message)}` : esc(t.last_error || "connecting")}</div></div>`);
    cards.push(`
      <div class="feed"><div class="row"><span class="st ${h.redis ? "ok" : "degraded"}"></span><span class="nm">Event bus</span></div>
      <div class="meta">${h.redis ? "Redis live" : "Redis down · polling Postgres"}</div></div>`);
    $("#feeds").innerHTML = cards.join("");
  }
  $("#feeds").addEventListener("click", async (e) => {
    const b = e.target.closest("[data-refresh]");
    if (!b) return;
    b.textContent = "…";
    try { await api(`/api/refresh/${b.dataset.refresh}`, { method: "POST" }); } catch (_) {}
    setTimeout(loadHealth, 4000);
  });

  // ---------- hazards ----------
  async function loadHazards() {
    try { state.hazards = await api("/api/hazards"); } catch (e) { $("#hazards").innerHTML = `<div class="empty">Could not load hazards: ${esc(e.message)}</div>`; return; }
    renderHazards();
    if (map.getSource("hazards")) {
      map.getSource("hazards").setData({ type: "FeatureCollection", features: state.hazards.features.filter((f) => f.geometry && visible(f)) });
      if (state.selected) map.setFeatureState({ source: "hazards", id: state.selected }, { selected: true });
    }
  }
  const visible = (f) => !state.onlyLogistics || LOGISTICS.has(f.properties.kind);

  function renderHazards() {
    const feats = (state.hazards?.features || []).filter(visible);
    $("#hazard-count").textContent = feats.length;
    if (!feats.length) {
      $("#hazards").innerHTML = `<div class="empty">No ${state.onlyLogistics ? "logistics-relevant " : ""}alerts are active in the feeds right now.<br>RASAD keeps polling; this list fills the moment an agency issues one.</div>`;
      return;
    }
    $("#hazards").innerHTML = feats.map((f) => {
      const p = f.properties;
      const srcs = [...new Set(p.sources.map((s) => s.source))];
      const rw = p.river_watch;
      return `<div class="hz ${state.selected === p.id ? "active" : ""}" data-id="${p.id}">
        <div class="bar" style="background:${SEV_COLOR[p.severity]}"></div>
        <div>
          <div class="k"><span>${esc(kindLabel(p.kind))}</span><span>${SEV[p.severity]}</span><span>until ${when(p.expires)}</span></div>
          <div class="t">${esc(p.title)}</div>
          <div class="a">${esc(p.area_desc || "")}</div>
          <div class="chips">
            ${srcs.map((s) => `<span class="chip src">${esc(FEED_NAMES[s] || s)}</span>`).join("")}
            ${p.located_by === "district" ? `<span class="chip warn">placed by district name</span>` : ""}
            ${!f.geometry ? `<span class="chip warn">not on map</span>` : ""}
            ${rw && rw.crossings_at_risk_3d ? `<span class="chip risk">${rw.crossings_at_risk_3d} crossings ≥50% flood risk, 3 days</span>` : ""}
          </div>
        </div></div>`;
    }).join("");
  }
  $("#hazards").addEventListener("click", (e) => {
    const el = e.target.closest(".hz");
    if (el) select(el.dataset.id, true);
  });
  $("#only-logistics").addEventListener("change", (e) => { state.onlyLogistics = e.target.checked; loadHazards(); });

  function bounds(geom) {
    const b = new maplibregl.LngLatBounds();
    const walk = (c) => (typeof c[0] === "number" ? b.extend(c) : c.forEach(walk));
    walk(geom.coordinates);
    return b;
  }

  async function select(id, fly) {
    if (state.selected && map.getSource("hazards")) map.setFeatureState({ source: "hazards", id: state.selected }, { selected: false });
    state.selected = id;
    if (map.getSource("hazards")) map.setFeatureState({ source: "hazards", id }, { selected: true });
    renderHazards();
    const f = state.hazards.features.find((x) => x.properties.id === id);
    if (!f) return;
    if (fly && f.geometry) map.fitBounds(bounds(f.geometry), { padding: { top: 60, bottom: 60, left: 60, right: 460 }, maxZoom: 9, duration: 800 });
    renderDrawer(f, null);
    try { renderDrawer(f, await api(`/api/hazards/${id}`)); } catch (_) {}
  }

  function renderDrawer(f, detail) {
    const p = f.properties;
    const msgs = detail?.messages || {};
    const sources = p.sources.map((s) => {
      const m = msgs[`${s.source}:${s.ref}`] || {};
      return `<div class="src-row">
        <div class="top"><b>${esc(FEED_NAMES[s.source] || s.source)}</b><span>${when(s.sent)}</span></div>
        <div>${esc(s.sender || m.sender || "")} · ${esc(s.msg_type || "")}</div>
        <div class="mono" style="font-size:11px;color:var(--muted);word-break:break-all">${esc(s.ref)}</div>
        <div>${s.raw_fetch_id ? `<a href="/api/raw/${s.raw_fetch_id}" target="_blank">Raw payload #${s.raw_fetch_id}</a>` : ""}${s.url ? ` · <a href="${esc(s.url)}" target="_blank" rel="noopener">Agency page</a>` : ""}</div>
        ${m.description ? `<div class="desc">${esc(m.description)}</div>` : ""}
        ${m.instruction ? `<div class="desc"><b>Instruction:</b> ${esc(m.instruction)}</div>` : ""}
      </div>`;
    }).join("");
    const rps = detail?.river_points || [];
    const rpRows = rps.filter((r) => !r.no_river).map((r) => {
      const bars = (r.forecast || []).slice(0, 10).map((d) => {
        const v = d.exceed_prob;
        const color = v == null ? "#7b858c" : v >= 0.5 ? "#e0442b" : v >= 0.2 ? "#e9c46a" : "#5cbf8a";
        return `<i title="${d.day}: ${pct(v)}" style="height:${v == null ? 3 : Math.max(3, v * 22)}px;background:${color}"></i>`;
      }).join("");
      return `<tr><td>${esc(r.name || "Unnamed")}<br><span style="color:var(--muted)">${esc(r.road_class || "")}</span></td>
        <td>${r.threshold_m3s ? Math.round(r.threshold_m3s) + " m³/s" : "pending"}${r.threshold_raw_fetch_id ? `<br><a href="/api/raw/${r.threshold_raw_fetch_id}" target="_blank" style="color:var(--accent)">history</a>` : ""}</td>
        <td><div class="probs">${bars}</div></td></tr>`;
    }).join("");
    $("#drawer-body").innerHTML = `
      <div class="hz-k" style="color:${SEV_COLOR[p.severity]};font-size:12px;text-transform:uppercase;letter-spacing:.08em">${esc(kindLabel(p.kind))} · ${SEV[p.severity]}</div>
      <h3>${esc(p.title)}</h3>
      <dl class="kv">
        <dt>Area</dt><dd>${esc(p.area_desc || "—")}</dd>
        <dt>Onset</dt><dd>${when(p.onset)}</dd>
        <dt>Expires</dt><dd>${when(p.expires)}</dd>
        <dt>Certainty</dt><dd>${pct(p.certainty)} (from CAP certainty)</dd>
        <dt>Footprint</dt><dd>${esc({ polygon: "agency polygon", circle: "agency circle", gdacs: "GDACS model polygons", district: "matched district boundaries", none: "not located" }[p.located_by] || p.located_by)}</dd>
        <dt>First seen</dt><dd>${when(p.first_seen)}</dd>
      </dl>
      <h4>Why RASAD believes this (${p.sources.length} source${p.sources.length === 1 ? "" : "s"})</h4>
      ${sources}
      <h4>River crossings watched</h4>
      ${rpRows ? `<table class="rp"><tr><th>Bridge</th><th>Flood level</th><th>Exceedance, next 10 days</th></tr>${rpRows}</table>
        <div class="desc">Flood level = median annual maximum of GloFAS reanalysis (1984–2022) at that river cell. Bars = share of the GloFAS ensemble above it.</div>`
        : `<div class="desc">${detail ? (["flood", "heavy_rain", "cyclone"].includes(p.kind) ? "No crossings analysed yet; river watch runs hourly for moderate and worse alerts." : "Not a river hazard.") : "Loading…"}</div>`}
    `;
    $("#drawer").hidden = false;
  }
  $("#drawer-close").addEventListener("click", () => {
    $("#drawer").hidden = true;
    if (state.selected) map.setFeatureState({ source: "hazards", id: state.selected }, { selected: false });
    state.selected = null;
    renderHazards();
  });

  // ---------- rivers and vehicles ----------
  async function loadRivers() {
    try { const d = await api("/api/river-points"); map.getSource("rivers")?.setData(d); } catch (_) {}
  }
  async function loadVehicles() {
    try { const d = await api("/api/vehicles"); map.getSource("vehicles")?.setData(d); } catch (_) {}
  }

  // ---------- live events ----------
  const evList = [];
  function pushEvent(ev) {
    if (ev.type === "heartbeat") return;
    const p = ev.payload || {};
    let text = ev.type;
    if (ev.type === "hazard.updated") text = `<b>${esc(p.action)}</b> ${esc(p.kind || "")} ${esc(p.title || p.hazard_id || "")} <span>(${esc(p.source || "")})</span>`;
    else if (ev.type === "vehicle.position") text = `<b>GPS</b> device ${esc(p.device_id)} ${Number(p.lat).toFixed(4)}, ${Number(p.lon).toFixed(4)}`;
    else if (ev.type === "river.updated") text = `<b>river watch</b> ${esc(p.points)} crossings, max 3-day risk ${pct(p.max_prob_3d)}`;
    evList.unshift(`<span class="ev">${new Date().toLocaleTimeString("en-IN", { hour12: false })} ${text}</span>`);
    evList.length = Math.min(evList.length, 25);
    $("#events").innerHTML = evList.join("");
  }

  let hzTimer = null;
  function connect() {
    const ws = new WebSocket(`${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`);
    ws.onopen = () => ($("#ws-state").className = "dot live");
    ws.onclose = () => { $("#ws-state").className = "dot down"; setTimeout(connect, 3000); };
    ws.onmessage = (m) => {
      const ev = JSON.parse(m.data);
      pushEvent(ev);
      if (ev.type === "hazard.updated" || ev.type === "river.updated") {
        clearTimeout(hzTimer);
        hzTimer = setTimeout(() => { loadHazards(); loadRivers(); }, 1500);
      } else if (ev.type === "vehicle.position") {
        loadVehicles();
      }
    };
  }

  async function seedEvents() {
    try { (await api("/api/events?limit=15")).reverse().forEach(pushEvent); } catch (_) {}
  }

  function refreshAll() { loadHealth(); loadHazards(); loadRivers(); loadVehicles(); }
  setInterval(loadHealth, 30000);
  setInterval(() => { loadHazards(); loadRivers(); }, 90000);
  setInterval(loadVehicles, 20000);
  seedEvents();
  connect();
})();
